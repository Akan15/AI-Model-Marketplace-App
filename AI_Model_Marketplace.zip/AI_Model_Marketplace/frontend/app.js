// Подключаем Web3.js
const Web3 = require('web3');

// ABI контракта
const abi = [
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "models",
    "outputs": [
      {
        "internalType": "string",
        "name": "name",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "description",
        "type": "string"
      },
      {
        "internalType": "uint256",
        "name": "price",
        "type": "uint256"
      },
      {
        "internalType": "address payable",
        "name": "creator",
        "type": "address"
      },
      {
        "internalType": "uint8",
        "name": "ratingCount",
        "type": "uint8"
      },
      {
        "internalType": "uint256",
        "name": "totalRating",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function",
    "constant": true
  }
];

// Адрес контракта
const address = "0x042FA667Aa87B6a65F77E33ab6B381be5f3578Fb";

// Подключение к локальной сети Ganache
const web3 = new Web3("http://127.0.0.1:7545");

// Создание экземпляра контракта
const contract = new web3.eth.Contract(abi, address);

// Логика для получения и отображения данных из контракта
async function fetchModels() {
  try {
    // Предположим, что у нас есть 5 моделей
    const modelsContainer = document.getElementById("models");

    for (let i = 0; i < 5; i++) {
      const model = await contract.methods.models(i).call();
      const modelElement = `
        <div class="model">
          <h2>${model.name}</h2>
          <p>${model.description}</p>
          <p>Цена: ${web3.utils.fromWei(model.price, "ether")} ETH</p>
          <p>Создатель: ${model.creator}</p>
          <p>Рейтинг: ${
            model.ratingCount > 0
              ? (model.totalRating / model.ratingCount).toFixed(2)
              : "Нет рейтингов"
          }</p>
        </div>
      `;
      modelsContainer.innerHTML += modelElement;
    }
  } catch (error) {
    console.error("Ошибка при получении моделей:", error);
  }
}

// Вызов функции при загрузке страницы
document.addEventListener("DOMContentLoaded", fetchModels);
